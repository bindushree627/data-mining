"""
Annapurna ingestion:
- reads all CSV/Parquet sales files
- normalizes the three vendor dialects
- trusts the filename business date
- deduplicates by (bill_no,line_no)
- rejects conflicting duplicate keys
- writes one Parquet file per store/day under:
  sales/year=YYYY/month=MM/store=Sxx/SALES_Sxx_YYYYMMDD.parquet
- uploads the curated Parquet files to MinIO

Run from VS Code terminal:
  python scripts/ingest.py --sales-dir ../data_2/data/sales --bucket annapurna
"""

from __future__ import annotations
import argparse, io, os, re, hashlib
from pathlib import Path
import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import boto3

FILE_RE = re.compile(r"SALES_(S\d{2})_(\d{8})(?:__R\d+)?\.(csv|parquet)$", re.I)
KEY = ["bill_no", "line_no"]
COLS = ["store_id","business_date","bill_no","line_no","product_code",
        "qty","unit_price","line_type","ts"]

def read_one(path: Path) -> pd.DataFrame:
    m = FILE_RE.match(path.name)
    if not m:
        raise ValueError(f"Unexpected sales filename: {path.name}")
    store, datestr, ext = m.group(1), m.group(2), m.group(3).lower()
    business_date = pd.to_datetime(datestr, format="%Y%m%d").date()

    if ext == "parquet":
        df = pd.read_parquet(path)
    else:
        raw = path.read_bytes()
        if store <= "S05":
            df = pd.read_csv(io.BytesIO(raw))
        elif store <= "S09":
            df = pd.read_csv(io.BytesIO(raw), sep=";")
            df = df.rename(columns={
                "item_code":"product_code", "quantity":"qty", "rate":"unit_price",
                "type":"line_type", "txn_time":"ts"
            })
        else:
            df = pd.read_csv(io.BytesIO(raw), encoding="utf-8-sig")

    df["store_id"] = store
    df["business_date"] = business_date
    for c in COLS:
        if c not in df.columns:
            raise ValueError(f"{path.name}: missing normalized column {c}")
    df = df[COLS].copy()
    df["line_no"] = pd.to_numeric(df["line_no"], errors="raise").astype("int64")
    df["qty"] = pd.to_numeric(df["qty"], errors="raise")
    df["unit_price"] = pd.to_numeric(df["unit_price"], errors="raise")
    df["ts"] = df["ts"].astype(str)
    return df

def canonical_hash(df: pd.DataFrame) -> str:
    x = df.sort_values(KEY)[KEY + ["product_code","qty","unit_price","line_type"]]
    payload = "\n".join(x.astype(str).agg("|".join, axis=1))
    return hashlib.sha256(payload.encode()).hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sales-dir", required=True)
    ap.add_argument("--bucket", default="annapurna")
    ap.add_argument("--endpoint", default="http://localhost:9000")
    ap.add_argument("--access-key", default="minioadmin")
    ap.add_argument("--secret-key", default="minioadmin")
    args = ap.parse_args()

    sales_dir = Path(args.sales_dir)
    paths = sorted([p for p in sales_dir.rglob("*")
                    if p.is_file() and p.suffix.lower() in {".csv",".parquet"}])
    if not paths:
        raise SystemExit("No sales files found.")

    frames = []
    for i,p in enumerate(paths, 1):
        frames.append(read_one(p))
        if i % 500 == 0:
            print(f"read {i}/{len(paths)} files")

    raw = pd.concat(frames, ignore_index=True)
    print("raw rows:", len(raw))

    # A resend can overlap the original. The safe unit is the line.
    # If the same key disagrees on content, fail rather than silently choose.
    check_cols = ["product_code","qty","unit_price","line_type"]
    grp = raw.groupby(KEY, sort=False)
    conflicts = grp[check_cols].nunique(dropna=False).max(axis=1)
    bad = conflicts[conflicts > 1]
    if len(bad):
        raise RuntimeError(f"Conflicting duplicate line keys: {len(bad)}")

    dedup = raw.drop_duplicates(KEY, keep="first").sort_values(
        ["business_date","store_id","bill_no","line_no"]
    )
    print("deduplicated rows:", len(dedup))
    print("checksum:", canonical_hash(dedup))

    out_root = Path("data/curated")
    out_root.mkdir(parents=True, exist_ok=True)

    # Remove/rebuild curated output, making repeated runs deterministic.
    for p in out_root.rglob("*.parquet"):
        p.unlink()

    s3 = boto3.client("s3", endpoint_url=args.endpoint,
                      aws_access_key_id=args.access_key,
                      aws_secret_access_key=args.secret_key,
                      region_name="us-east-1")
    try:
        s3.head_bucket(Bucket=args.bucket)
    except Exception:
        s3.create_bucket(Bucket=args.bucket)

    total_files = 0
    total_bytes = 0
    for (d, store), g in dedup.groupby(["business_date","store_id"], sort=True):
        year, month = d.year, d.month
        rel = Path(f"sales/year={year}/month={month:02d}/store={store}/"
                   f"SALES_{store}_{d:%Y%m%d}.parquet")
        local = out_root / rel
        local.parent.mkdir(parents=True, exist_ok=True)
        pq.write_table(pa.Table.from_pandas(g, preserve_index=False), local,
                       compression="zstd")
        key = str(rel).replace(os.sep, "/")
        s3.upload_file(str(local), args.bucket, key)
        total_files += 1
        total_bytes += local.stat().st_size

    print("curated files:", total_files)
    print("curated bytes:", total_bytes)
    print(f"s3://{args.bucket}/sales/year=YYYY/month=MM/store=Sxx/")
    print("ingestion complete")

if __name__ == "__main__":
    main()
