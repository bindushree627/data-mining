import argparse, hashlib
from pathlib import Path
import pandas as pd
import pyarrow.parquet as pq

KEY=["bill_no","line_no"]
def checksum(df):
    x=df.sort_values(KEY)[KEY+["product_code","qty","unit_price","line_type"]]
    payload="\n".join(x.astype(str).agg("|".join,axis=1))
    return hashlib.sha256(payload.encode()).hexdigest()

ap=argparse.ArgumentParser()
ap.add_argument("--sales-dir", required=True)
args=ap.parse_args()

# Validate idempotency from the curated result.
files=sorted(Path("data/curated").rglob("*.parquet"))
dfs=[pq.read_table(p).to_pandas() for p in files]
df=pd.concat(dfs,ignore_index=True)
print("row_count =",len(df))
print("checksum   =",checksum(df))
print("duplicate_keys =",df.duplicated(KEY).sum())
