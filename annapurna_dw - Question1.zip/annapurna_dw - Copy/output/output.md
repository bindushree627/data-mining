PART A — PLATFORM AND LANDING

PS C:\Users\ub02-glab-064> cd "C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw"

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> docker compose ps

NAME                 IMAGE                  STATUS
annapurna-postgres   postgres:16            Up
annapurna-minio      quay.io/minio/minio    Up

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> .\.venv\Scripts\python.exe --version

Python 3.13.1

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> .\.venv\Scripts\python.exe scripts\ingest.py --sales-dir "C:\Users\ub02-glab-064\Downloads\data_2\data\sales"

read 500/4457 files
read 1000/4457 files
read 1500/4457 files
read 2000/4457 files
read 2500/4457 files
read 3000/4457 files
read 3500/4457 files
read 4000/4457 files

raw rows: 1137585
deduplicated rows: 1120924
checksum: e0387aa5e8bb331d2f0fea343b6f839a8db500681e52b0c40abf22298a63ce9a
curated files: 4389
curated bytes: 37530099

s3://annapurna/sales/year=YYYY/month=MM/store=Sxx/

ingestion complete

Source: 4457 files, 68706877 bytes
Curated: 4389 files, 37530099 bytes
S03 October 2024: 31 files, 324103 bytes
Candidate-byte reduction: 37205996 bytes (~99.14%).






PART B — IDEMPOTENT LOADING

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> .\.venv\Scripts\python.exe scripts\validate.py

Run 1:
row_count = 1120924
checksum   = e0387aa5e8bb331d2f0fea343b6f839a8db500681e52b0c40abf22298a63ce9a
duplicate_keys = 0

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> .\.venv\Scripts\python.exe scripts\validate.py

Run 2:
row_count = 1120924
checksum   = e0387aa5e8bb331d2f0fea343b6f839a8db500681e52b0c40abf22298a63ce9a
duplicate_keys = 0

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> .\.venv\Scripts\python.exe scripts\validate.py

Run 3:
row_count = 1120924
checksum   = e0387aa5e8bb331d2f0fea343b6f839a8db500681e52b0c40abf22298a63ce9a
duplicate_keys = 0

Conclusion: all three runs produced the same row count and checksum, with zero duplicate keys. The load is idempotent.








PART C — DASHBOARD MODEL

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> docker exec -it annapurna-postgres psql -U annapurna -d annapurna

SELECT COUNT(*) FROM stores;
SELECT COUNT(*) FROM product_categories;
SELECT COUNT(*) FROM products;
SELECT COUNT(*) FROM price_revisions;

stores = 12
product_categories = 14
products = 1224
price_revisions = 4320

\q

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> .\.venv\Scripts\python.exe -c "import duckdb; con=duckdb.connect(); con.execute(\"INSTALL postgres; LOAD postgres;\"); sql=open('sql/01_dashboard_views.sql').read(); con.execute(sql); print('Part C view created successfully'); print('Dashboard rows:',con.execute('SELECT COUNT(*) FROM dashboard_sales').fetchone()[0])"

Part C view created successfully
Dashboard rows: 766796

Revenue lines: SALE, RETURN, DISCOUNT, VOID
Excluded: TAX, TENDER
Product resolution: product_code + business_date against valid_from/valid_to.








PART D — HISTORICAL PRICING

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> docker exec -it annapurna-postgres psql -U annapurna -d annapurna

SELECT product_code, product_name, product_sk
FROM products
WHERE product_code = 'P100019';

P100019 | Sunfeast Cookies 150g | 1003

SELECT revision_id, selling_price, effective_from, effective_to
FROM price_revisions
WHERE product_sk = 1003
ORDER BY effective_from;

500009 | 62.95 | 2022-01-01 | 2024-04-13
500010 | 64.89 | 2024-04-14 | 2024-09-25
500011 | 74.65 | 2024-09-26 | 9999-12-31

March 2024: ₹62.95
December 2024: ₹74.65

The same period-based query changes only the reporting period.









PART E — CROSS-SYSTEM QUERY

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> .\.venv\Scripts\python.exe -c "import duckdb; con=duckdb.connect(); con.execute(\"INSTALL postgres; LOAD postgres;\"); sql=open('sql/03_cross_system.sql').read(); con.execute(sql); print('Cross-system query executed successfully')"

Cross-system query executed successfully

Parquet source:
data/curated/sales/year=2024/month=10/store=S03/*.parquet

S03 October: 31 Parquet files read.

PostgreSQL scans:
stores = 12 rows
products = 1224 rows
categories = 14 rows

EXPLAIN ANALYZE:
READ_PARQUET + PostgreSQL TABLE_SCAN + HASH_JOIN
Total time: ~0.0382 seconds

No copying of one side into the other was required.









PART F — RECONCILIATION

PS C:\Users\ub02-glab-064\Downloads\annapurna_dw_vs_code\annapurna_dw> .\.venv\Scripts\python.exe -c "import duckdb; con=duckdb.connect(); con.execute(\"INSTALL postgres; LOAD postgres;\"); sql=open('sql/05_reconciliation.sql').read(); con.execute(sql)"

MONTH       CALCULATED       FINANCE          DIFFERENCE
2024-01     38446071.33      38446071.33          0.00
2024-02     34887085.55      34887085.55          0.00
2024-03     41971649.09      42457899.09    -486250.00
2024-04     37958457.37      37958457.37          0.00
2024-05     41764716.40      41764716.40          0.00
2024-06     38987082.82      38987082.82          0.00
2024-07     40295160.11      40527291.81    -232131.70
2024-08     45252181.75      45252181.75          0.00
2024-09     44615037.46      44615037.46          0.00
2024-10     56359195.92      56359195.92          0.00
2024-11     51583838.47      51583838.47          0.00
2024-12     50745259.48      50745209.00         50.48


Classification:
July = documented source-data issue; S07 had 3 missing export days and finance used manual figures.
March = revenue-definition/source reconciliation difference requiring finance review.
December = small source/revenue-definition reconciliation difference requiring finance confirmation.
October = exact match; TAX/TENDER were not counted.