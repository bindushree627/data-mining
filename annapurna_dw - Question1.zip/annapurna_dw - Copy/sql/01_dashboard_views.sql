-- PART C: Dashboard-ready analytical view

CREATE OR REPLACE VIEW dashboard_sales AS
WITH resolved_sales AS (
    SELECT
        s.business_date,
        s.store_id,
        s.bill_no,
        s.line_no,
        s.product_code,
        s.qty,
        s.unit_price,
        s.line_type,
        p.product_sk,
        p.category_id
    FROM read_parquet(
        'data/curated/sales/**/*.parquet',
        hive_partitioning = true
    ) s
    JOIN postgres_scan(
        'host=localhost port=5432 dbname=annapurna user=annapurna password=annapurna',
        'public',
        'products'
    ) p
      ON p.product_code = s.product_code
     AND s.business_date >= p.valid_from
     AND s.business_date <= p.valid_to
)
SELECT
    business_date,
    store_id,
    product_sk,
    category_id,
    bill_no,
    line_no,
    qty,
    unit_price,
    line_type,
    qty * unit_price AS revenue_amount,
    EXTRACT(DOW FROM business_date) AS weekday_number,
    EXTRACT(MONTH FROM business_date) AS month_number
FROM resolved_sales
WHERE line_type IN ('SALE', 'RETURN', 'DISCOUNT', 'VOID');