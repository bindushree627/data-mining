-- Cross-system query: DuckDB reads Parquet from the object-store
-- path and PostgreSQL dimensions directly. No table is first copied
-- from one system into the other.

INSTALL postgres;
LOAD postgres;

ATTACH 'dbname=annapurna user=annapurna password=annapurna host=localhost port=5432'
AS pg (TYPE POSTGRES, READ_ONLY);

SELECT
    sf.store_id,
    s.store_name,
    pc.category_name,
    strftime(sf.business_date, '%A') AS day_of_week,
    strftime(sf.business_date, '%Y-%m') AS month,
    SUM(CAST(sf.qty * sf.unit_price AS DECIMAL(18,2))) AS revenue_inr
FROM read_parquet(
       'data/curated/sales/**/*.parquet',
       hive_partitioning=true
     ) sf
JOIN pg.public.products p
  ON p.product_sk = CAST(
       -- product_sk is not in the sales export, so resolve the
       -- historically valid product by code + business date.
       (
         SELECT product_sk
         FROM pg.public.products p2
         WHERE p2.product_code = sf.product_code
           AND sf.business_date BETWEEN p2.valid_from AND p2.valid_to
         ORDER BY p2.valid_from DESC
         LIMIT 1
       ) AS BIGINT)
JOIN pg.public.product_categories pc
  ON pc.category_id = p.category_id
JOIN pg.public.stores s
  ON s.store_id = sf.store_id
WHERE sf.line_type IN ('SALE','RETURN','DISCOUNT','VOID')
GROUP BY 1,2,3,4,5
ORDER BY month, store_id, category_name, day_of_week;
