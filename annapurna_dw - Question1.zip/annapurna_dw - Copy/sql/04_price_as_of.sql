-- Same query shape works for any reporting period.
-- Change ONLY :report_month.
-- This answers "what was the authoritative selling price in that month?"
-- using the price revision effective during the reporting period.

-- Example for March 2024:
WITH params AS (
  SELECT DATE '2024-03-01' AS report_start,
         DATE '2024-03-31' AS report_end
)
SELECT
    p.product_sk,
    p.product_code,
    p.product_name,
    pr.selling_price,
    pr.effective_from,
    pr.effective_to
FROM products p
JOIN price_revisions pr
  ON pr.product_sk = p.product_sk
CROSS JOIN params x
WHERE p.product_code = 'P100008'  -- replace with the requested biscuit code
  AND pr.effective_from <= x.report_end
  AND pr.effective_to >= x.report_start
ORDER BY pr.effective_from;

-- To run for last month, replace ONLY report_start/report_end.
-- Do not change the join logic.
