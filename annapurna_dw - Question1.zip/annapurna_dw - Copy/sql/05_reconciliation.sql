WITH pipeline AS (
  SELECT
    strftime(business_date, '%Y-%m') AS month,
    SUM(CAST(qty * unit_price AS DECIMAL(18,2))) AS pipeline_revenue
  FROM read_parquet('data/curated/sales/**/*.parquet', hive_partitioning=true)
  WHERE line_type IN ('SALE','RETURN','DISCOUNT','VOID')
  GROUP BY 1
)
SELECT * FROM pipeline ORDER BY month;
